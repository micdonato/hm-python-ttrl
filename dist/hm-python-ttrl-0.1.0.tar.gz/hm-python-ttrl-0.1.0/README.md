# hm-python-ttrl
following tutorial for hypermodern python

From [here](https://cjolowicz.github.io/posts/hypermodern-python-01-setup/)
